(function() {
    'use strict';

    var sidebarComponent = {
        controller: SidebarComponent,
        bindings: {},
        templateUrl: '/partials/mail/components/sidebar/sidebar.view.html'
    };

    function SidebarComponent($scope) {

    }

    module.exports = sidebarComponent;
}());