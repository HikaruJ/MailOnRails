(function() {
    "use strict";

    var config = {
        baseUrl: 'http://localhost:3000',
        port: 80
    };

    module.exports = config;
}());